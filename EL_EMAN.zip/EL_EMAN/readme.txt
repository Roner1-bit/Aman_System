1st:- import sql file in my sql name the database (el_eman_system)
2nd:-open visual studio the open folder then select EL_EMAN folder
3rd:- open terminal write (npm run dev)
4th:-open postman make import to json file that in folder postmanapi